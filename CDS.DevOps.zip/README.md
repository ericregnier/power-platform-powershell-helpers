# Introduction 
ALM strategy including Release and Build Pipelines are based on:
- Microsoft’s Power Platform ALM recommendation:
https://docs.microsoft.com/en-us/power-platform/alm/
- Dynamics 365 ALM whitepaper:
https://www.microsoft.com/en-us/download/details.aspx?id=57777
- Microsoft FastTrack ALM practices
- Lesson learns from past projects

## Main guiding principles:
1.	Source control is the source of truth for all source including configuration
2.	Same publisher and prefix in all environments in case components need to change “owner”
3.	One dev env per managed Solution export and therefore should practice Solution Segmentation and Layering as explained further
4.	One repo per Module/Area/Solution
5.	No unmanaged changes are made any downstream environments

## Setup (TODO)
1. Set solution name in environment variables
2. Set solutionpackagefilename in importconfig.xml in PackageDeployment/PkgFolder/ImportConfig.xml
3. Set data import FetchXml in BuildTools/DataFetchXml/ folder
4. TODO


#Tools and Libraries used
| Name | Purpose | Reference |
|-|-|-|
|Power Apps Build tools|To handle CDS deployment preparation tasks and provision environments|https://docs.microsoft.com/en-us/powerapps/developer/common-data-service/build-tools-overview|
|Solution Packager|In Build pipelines to unpack CDS solution in source control|https://docs.microsoft.com/en-us/powerapps/developer/common-data-service/compress-extract-solution-file-solutionpackager|
|Package Deployer|To deploy a package to target environment. A package is not only a solution, but may include >1 solution, import file(s), script(s) to run|https://docs.microsoft.com/en-us/powerapps/developer/common-data-service/package-deployer/create-packages-package-deployer|
|Microsoft.Xrm.Tooling.CrmConnector.PowerShell|To connect to CDS in PowerShell|https://docs.microsoft.com/en-us/powershell/module/microsoft.xrm.tooling.crmconnector.powershell|
|Microsoft.Xrm.Data.PowerShell|To execute CDS transaction in PowerShell|https://github.com/seanmcne/Microsoft.Xrm.Data.PowerShell|
|Microsoft.Xrm.DevOps.Data.PowerShell PowerShell|For automatically extract prepare data import files compatible with the Configuration Migration Tool|https://github.com/abvogel/Microsoft.Xrm.DevOps.Data|
|FakeXrmEasy|Helper to plugin unit test|https://dynamicsvalue.com/|
|XrmDefinitelyTyped|To generate CDS TypeScript files|https://github.com/delegateas/XrmDefinitelyTyped/wiki|
|XrmContext|To generate early bound entities|https://github.com/delegateas/XrmContext|
|Spkl|Helpers to deploy components from local to Dev|https://github.com/scottdurow/SparkleXrm/wiki/spkl|

#Git Branching Strategy
Every branching was different per project and typically customers have strong requirements on this. I assume for the template the simplest approach: feature branching with Release Tags    
https://docs.microsoft.com/en-us/azure/devops/repos/git/git-branching-guidance?view=azure-devops  
![](/Documentation/Images/branching.png)

#High-level Pipeline Processes
The purpose of the following is to illustrate the process and purpose of each CDS pipeline (build and release).  

##CDS env provisioning
Used to reset or standup a new CDS/D365 environment.  
![](/Documentation/Images/provisioning.png =300x)

##CDS unpack build pipeline
Used to unpack a CDS solution from Dev, extract the master/reference data from Dev and commit to Git.  
![](/Documentation/Images/unpack.png =300x) --> 
![](/Documentation/Images/ADO-unpack.png =300x)

##CDS pack build pipeline
Used to prepare a CDS deployment package and save as a Azure DevOps artifact for a future deployment.  
![](/Documentation/Images/pack.png =300x)  --> 
![](/Documentation/Images/ADO-pack.png =300x)

##Release pipeline tasks
The tasks executed for a deployment to a target environment.  
![](/Documentation/Images/release.png =300x)  --> 
![](/Documentation/Images/ADO-release.png =300x)

##Release pipeline
The release pipeline and stages.  
![](/Documentation/Images/release-pipeline.png =300x)  --> 
![](/Documentation/Images/ADO-release-pipeline.png =300x)

#Solution Layering and Segmentation
Solution Layering and Segmentation is key to have a successfully CDS ALM and CDS solution strategy that simpifies and avoids dependencies.
For more info: https://docs.microsoft.com/en-us/powerapps/maker/common-data-service/solution-layers  
![](/Documentation/Images/solution-layering.png =600x)

###Another Lens
![](/Documentation/Images/solution-layering-2.png =800x) 

#Visual Studio Solution
![](/Documentation/Images/vs-solution.png =250x)
| Project Name | Purpose |
|-|-|
|D365.Template.BuildTools|Placeholder for all the scripts and tools used. Place where solution files and data are committed|
|D365.Template.Common|Shared Project containing common helpers used across difference projects|
|D365.Template.Entities|TShared Project containing early bound entities and Linq Context|
|D365.Template.PackageDeployment|Packager Deployer project|
|D365.Template.Plugins|All Plugins code|
|D365.Template.Plugins.Tests|All Plugins Unit Tests|
|D365.Template.WebResources|Web Side Project containing TypeScript files and where JavaScript files are transpile|

Name of projects format is typically company.system.module.components (e.g. DXC.CDS.Sales.Plugins). Many developers would find it old school with prefixes but kept as is for now. Note the physical folder of the solution has no prefix. This simplifies greatly the scripting which in a DevOpsy world has a lot.  
![](/Documentation/Images/vs-folders.png =250x)  
###Notes
- If want to keep the prefix convention, we should rename from D365 to **CDS** to be precise. I just didn’t have the time…
- Didn’t include Custom Workflow Activities since Microsoft has a strong push to use Power Automate instead and if need be, my personal preference is Custom Actions

#Power Automate (PA) flow to trigger unpack
A PA button flow that initiates the unpack and commits the changes. Because of the CI/CD triggers the full solution build/pack and deployment to test are automated. The purpose of this it to make it super simple for functional consultant and/or citizen developers aka makers to commit their work because they typically won’t have Visual Studio installed and not too proficient with Git and other DevOps tools. Needless to say, all CDS configurations/customizations are done directly in maker portal and in CDS/D365 and as such, they need a way to commit those changes in Git because for a healthy ALM, source should be the source of truth, not a dev environment. Furthermore, Git where all deployment artifacts are built for a target release.  
![](/Documentation/Images/unpack-flow.png =300x)
![](/Documentation/Images/unpack-button.png =300x)

#Azure DevOps (ADO)
Using classic interface, rather than the recommended yaml because easier to configure especially if target audience are functional consultants/makers/citizen developers.

#Considerations
- Start of the project, probably need a senior or solution architect to identify solution strategy and prepare repos, ADO and VS solution based on the DevOps template.
- Understand target audience are functional consultants/makers/citizen developers but might be lots of fishhooks where a need of a developer is required at times (e.g. merge conflicts) and also other moments like entity model review, PA reviews, workflow reviews, etc
- From experience DevOps was also a continuous improving process which has continuous enhancements to the builds and pipelines
- Maybe the simplest strategy for a simple CDS implementation is not for Git to be the source of truth, but not only is it not recommended by Microsoft’ ALM best practices and FastTrack team, having a future lens, as more the solution grows and evolves, better to be setup correctly from day 1…

#Outstanding Items to do
- See ADO backlog: https://dev.azure.com/DXCEclipseDeliveryExcellence/ECL%20D365%20Template/_backlogs/backlog/ECL%20D365%20Template%20Team/Requirements
- Discuss Git branching strategy with Tash/Faranak/Rami
- Automatic publish release notes to wikis
- DevOps for unmanaged solutions?
- Configure ADO naming conventions for builds and releases
- Set Plugin assembly version number and match solution version number
- Solution Patching in ADO
- EasyRepro and UI testing
- Static code analysis. SonarQube?
- Add Flow Checker
- Cancel previous ADO approval(s) if new one is sent