﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System;

namespace D365.Template.Common.Services
{
    internal abstract class BaseService
    {
        protected IOrganizationService OrgService { get; set; }
        protected IOrganizationService ElevatedService { get; set; }
        protected ITracingService TracingService { get; set; }

        public BaseService(IOrganizationService orgService, ITracingService tracingservice)
        {
            OrgService = orgService;
            TracingService = tracingservice;
        }
        public BaseService(IOrganizationService orgService, IOrganizationService elevatedService, ITracingService tracingservice) : this(orgService, tracingservice)
        {
            ElevatedService = elevatedService;
        }
        protected void Trace(string trace)
        {
            if (TracingService != null)
            {
                TracingService.Trace(trace);
            }
        }
    }
}
