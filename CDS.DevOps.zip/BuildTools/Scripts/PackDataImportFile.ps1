﻿Param(
    [string] [Parameter()] $ImportFilePath
)
if (!(Get-Module "Microsoft.Xrm.DevOps.Data.PowerShell")) {
	Install-Module -Name Microsoft.Xrm.DevOps.Data.PowerShell #-Force -Verbose -Scope CurrentUser
}

$path = if ($ImportFilePath -eq $null) { "..\PackageDeployment\PkgFolder\ImportFiles\Data" } else { $ImportFilePath }
Write-Host $path

#Export-CrmDataPackage -ZipPath $path

Compress-Archive -Path "BuildTools\SolutionPackage\Data\*.xml" -CompressionLevel Fastest -DestinationPath $path -Force

#TODO set env:IMPORTFILEPATH in ImportConfig.xml