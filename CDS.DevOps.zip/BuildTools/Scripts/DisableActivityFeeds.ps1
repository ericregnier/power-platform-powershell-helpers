﻿function Disable-DefaultActivityFeeds
(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient] $Conn
) {
    Write-Host "Disabling Activity Feeds"

    $fetchXml = 
    @"<fetch>
		  <entity name="msdyn_postconfig" >
			<attribute name="statecode" />    
			<attribute name="msdyn_configurewall" />    
			<attribute name="msdyn_postconfigid" />
			<attribute name="msdyn_otc" />    
			<attribute name="statuscode" />    
			<filter type="and" >
			  <condition attribute="statecode" operator="eq" value="0" />
			</filter>
		  </entity>
	</fetch>"@

    $activityFeeds = Get-CrmRecordsByFetch -conn $Conn -Fetch $fetchXml 
    $user = $null
 
    if ($activityFeeds.CrmRecords.Count -gt 0) {
        $activityFeeds.CrmRecords | ForEach-Object -Process {
            #User needs to be the last entity otherwise CRM throws exception
            if ($_.msdyn_otc -eq 8) {
                $user = ($_)          
            }
            else {
                #Updating the "Wall Enabled" config
                $_.msdyn_configurewall = $false
                Set-CrmRecord -conn $Conn -CrmRecord $_
                #Deactivating the config
                Set-CrmRecordState -conn $Conn -EntityLogicalName msdyn_postconfig -Id $_.msdyn_postconfigid -StateCode 1 -StatusCode 2
            }       
        }
        if ($null -ne $user) {
            $user.msdyn_configurewall = $false
            #Updating the "Wall Enabled" config
            Set-CrmRecord -conn $Conn -CrmRecord $user 
            #Deactivating the config
            Set-CrmRecordState -conn $Conn -EntityLogicalName msdyn_postconfig -Id $user.msdyn_postconfigid -StateCode 1 -StatusCode 2
        }
    }
	Write-Host "Disabled Default Activity Feeds"
}