﻿[string]$drop = "$env:SYSTEM_DEFAULTWORKINGDIRECTORY/$env:RELEASE_PRIMARYARTIFACTSOURCEALIAS/drop"

$path = $drop + "/BuildTools/bin/Release/Data/data.xml"
Write-Host "data.xml path: $path"

$xml = [xml](Get-Content $path)
$xml.Load($path)

$configSettings = $xml.entities.entity | where {$_.name -eq "TODO config entity to replace"} 

$pipelineVariables = @{}
$pipelineVariables.add("Secret",$env:CLIENTSECRET)
$pipelineVariables.add("ClientID", $env:CLIENTID)

Write-Host "Replacing values..."
foreach ($record in $configSettings.records.ChildNodes) {
    foreach ($field in $record.field) {       
        if($pipelineVariables.ContainsKey($field.value)) {
			Write-Host "Found: " + $field.value
            $value = $record.field | where {$_.name -eq "TODO TARGET FIELD"}
			if($value) {
				$value.SetAttribute("value", $pipelineVariables[$field.value]);
			}
            break;
        }
    }
}
Write-Host "Save new data.xml"
$xml.Save($path)
##toDO move to packagedeployer

Write-Host "Compressing data file"
$compressPath  = $drop + "/BuildTools/bin/Release/Data/*"
$destinationPath  = $drop + "/PackageDeploment/bin/Release/PkgFolder/ImportFiles/Data"
Compress-Archive -Path $compressPath -CompressionLevel Fastest -DestinationPath $destinationPath -Force