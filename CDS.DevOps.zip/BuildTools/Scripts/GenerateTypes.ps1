Param(
    [string] [Parameter()] $ServerUrl,
    [string] [Parameter()] $UserName,
    [string] [Parameter()] $Password
)
if (!$ServerUrl -Or !$UserName -Or !$Password)
{
    $Credentials = Get-Credential
	$UserName =  $Credentials.GetNetworkCredential().UserName
	$Password =  $Credentials.GetNetworkCredential().Password
}

Write-Host "Cleaning up files"
Remove-Item Entities\Context -Force -Recurse -ErrorAction Ignore
Remove-Item WebResources\Typings\CDS -Force -Recurse -ErrorAction Ignore

New-Item -ItemType Directory -Path Entities\Context
New-Item -ItemType Directory -Path WebResources\Typings\CDS

BuildTools\XrmContext\XrmContext.exe /username:$UserName /password:$Password /useconfig /out:"Entities/Context/" /url:$ServerUrl
BuildTools\XrmDefinitelyTyped\XrmDefinitelyTyped.exe /username:$UserName /password:$Password /useconfig /url:$ServerUrl /out:"WebResources/Typings/CDS" /jsLib:"WebResources/JsLibraries"

Write-Host "Earlybound entities and TypeScript files generated"