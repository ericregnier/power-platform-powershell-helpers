Param(
    [string] [Parameter()] $ServerUrl,
    [string] [Parameter()] $UserName,
    [string] [Parameter()] $Password
)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
if (!(Get-Module "Microsoft.Xrm.DevOps.Data.PowerShell")) {
    Write-Host "Installing Microsoft.Xrm.DevOps.Data.PowerShell"
	Install-Module -Name Microsoft.Xrm.DevOps.Data.PowerShell -Force -Verbose -Scope CurrentUser
}
if (!(Get-Module "Microsoft.Xrm.Tooling.CrmConnector.PowerShell")) {
    Write-Host "Installing Microsoft.Xrm.Tooling.CrmConnector.PowerShell"
	Install-Module -Name Microsoft.Xrm.Tooling.CrmConnector.PowerShell -Force -Verbose -Scope CurrentUser
}

if (!$ServerUrl -Or !$UserName -Or !$Password) {
    $Conn = Get-CrmConnection -Interactive
}
else {
    Write-Host "Connecting to CDS" $ServerUrl
        
    $Conn = Get-CrmConnection -ConnectionString "AuthType=Office365;Username=$UserName;Password=$Password;Url=$ServerUrl"
}

$fetches = New-Object System.Collections.Generic.List[string]

Get-ChildItem -Path BuildTools\DataFetchXml -File -Filter *.xml | 
Foreach-Object {
    $xml = Get-Content $_.FullName
    $fetches.Add($xml)
}
Write-Output($fetches)

Write-Host "Generating data package"
$packages = Get-CrmDataPackage -Conn $Conn -Fetches $fetches.ToArray() -DisablePluginsGlobally $true

#$packages.Data.ContentTypes.InnerXml | Out-File -FilePath  BuildTools\SolutionPackage\Data\[Content_Types].xml
$packages.Data.InnerXml | Out-File -FilePath  BuildTools\SolutionPackage\Data\data.xml
$packages.Schema.InnerXml | Out-File -FilePath BuildTools\SolutionPackage\Data\data_schema.xml