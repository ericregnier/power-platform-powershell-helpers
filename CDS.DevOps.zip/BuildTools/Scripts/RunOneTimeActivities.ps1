﻿Param(
    [string] [Parameter()] $ServerUrl,
    [string] [Parameter()] $UserName,
    [string] [Parameter()] $Password,
    [boolean] [Parameter()] $PerformOTAs = $false,
    [boolean] [Parameter()] $PerformPostOTAs = $false
)
#Set-ExecutionPolicy –ExecutionPolicy Unrestricted

if (!(Get-Module "Microsoft.Xrm.Data.PowerShell")) {
	Install-Module -Name Microsoft.Xrm.Data.PowerShell -Force -Verbose -Scope CurrentUser
}
else {
    Write-Host "Microsoft.Xrm.Data.PowerShell already installed"
}

if (!$ServerUrl -Or !$UserName -Or !$Password) {
    $Conn = Get-CrmConnection -Interactive
}
else {
    Write-Host "Connecting to CDS" $ServerUrl
    $Conn = Get-CrmConnection -ConnectionString "AuthType=Office365;Username=$UserName;Password=$Password;Url=$ServerUrl"
}

if ($false -eq $PerformOTAs) {
    #. "BuildTools\bin\Release\Scripts\UninstallSolutions.ps1"
    #. "BuildTools\bin\Release\Scripts\DisableActivityFeeds.ps1"
    #. "BuildTools\bin\Release\Scripts\DisableD365DocumentTemplates.ps1"
    #. "BuildTools\bin\Release\Scripts\DisableD365Processes.ps1"
    #. "BuildTools\bin\Release\Scripts\SetRootBusinessUnit.ps1"
    . "BuildTools\bin\Release\Scripts\SetSystemSettings.ps1"

    #Remove-DefaultSolutions -Conn $Conn
		
    Set-SystemSettings -Conn $Conn
		
    #Disable-DefaultActivityFeeds -Conn $Conn
		
    #Update-RootBU -Conn $Conn
		
    #Disable-DefaultDocumentTemplates -Conn $Conn

    #Disable-DefaultProcesses -Conn $Conn
}
if ($true -eq $PerformPostOTAs) {
  
}