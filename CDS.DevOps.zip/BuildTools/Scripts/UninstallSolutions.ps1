﻿function Delete-UnwantedSolutions
(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient] $Connection
) {
    Write-Host "Fetching solutions to delete" -ForegroundColor Green 

    $fetchXml =
    @"
<fetch>
  <entity name="solution" >
    <attribute name="uniquename" />
    <attribute name="solutionid" />
    <attribute name="friendlyname" />
    <attribute name="installedon" />
    <filter type="or" >
      <condition attribute="uniquename" operator="in" >
        <value>OrganizationInsightsSolution</value>
      </condition>
    </filter>
	<order attribute="installedon" descending="true" />
  </entity>
</fetch>
"@
		
    $solutions = Get-CrmRecordsByFetch -conn $Connection -Fetch $fetchXml

    if ($solutions.CrmRecords.Count -gt 0) {
        $solutions.CrmRecords | ForEach-Object -Process {
         
            Write-Host "Deleting solution:" $_.uniquename -ForegroundColor Green
           
            $ref = new-object Microsoft.Xrm.Sdk.EntityReference
            $ref.LogicalName = "solution"
            $ref.Id = $_.solutionid

            $deleteRequest = new-object Microsoft.Xrm.Sdk.Messages.DeleteRequest
            $deleteRequest.Target = $ref  
				
            $Connection.ExecuteCrmOrganizationRequest($deleteRequest)

            Write-Host "Solution:" $_.uniquename "deleted" -ForegroundColor Green
        }
    }
    else {
        Write-Host "No solutions to delete" -ForegroundColor Cyan
    }
}