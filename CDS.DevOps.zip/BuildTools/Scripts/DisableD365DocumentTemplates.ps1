﻿function Disable-DefaultDocumentTemplates
(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient] $Conn
) {
    Write-Host "Disabling default document templates"
    $fetchXml = 
    @"<fetch>
        <entity name="documenttemplate">
            <attribute name="documenttemplateid" />   
            <filter type="and">
                <filter type="or">
                    <condition attribute="name" operator="eq" value="Campaign Overview" />
                    <condition attribute="name" operator="eq" value="Case SLA Status" />
                    <condition attribute="name" operator="eq" value="Case Summary" />
                    <condition attribute="name" operator="eq" value="Pipeline Management" />
                    <condition attribute="name" operator="eq" value="Account Summary" />
                    <condition attribute="name" operator="eq" value="Campaign Summary" />
                    <condition attribute="name" operator="eq" value="Case Summary" />
                    <condition attribute="name" operator="eq" value="Invoice" />
                    <condition attribute="name" operator="eq" value="Invoice Summary" />
                    <condition attribute="name" operator="eq" value="Opportunity Summary" />
                    <condition attribute="name" operator="eq" value="Order Summary" />
                    <condition attribute="name" operator="eq" value="Print quote for customer" />
                    <condition attribute="name" operator="eq" value="Quote Summary" />
                </filter>
                <condition attribute="status" operator="ne" value="1" />
            </filter>
        </entity>
    </fetch>"@

    $results = Get-CrmRecordsByFetch -conn $Conn -Fetch $fetchXml

    if ($results.CrmRecords.Count -gt 0) {
        $results.CrmRecords | ForEach-Object -Process {
            $doc = @{ }
            $doc.Add("status", $true)
            Set-CrmRecord -conn $Conn -Fields $doc -Id $_.documenttemplateid -EntityLogicalName "documenttemplate"
        }
    } 
	Write-Host "Disabled Default Document Templates"
}
