function Get-ServiceEndpoint
(
    [string] $QueueName,
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient] $Connection
) {
    $fetchXml =
    @"
<fetch>
  <entity name="serviceendpoint"> 
    <attribute name="serviceendpointid" />
    <filter type="and">
        <condition attribute="path" operator="eq" value="$QueueName" />
    </filter>
  </entity>
</fetch>
"@ 

    #Write-Host $fetchXml

    $response = Get-CrmRecordsByFetch -conn $Connection -Fetch $fetchXml

    $endpoint = $null

    if ($response.CrmRecords.Count -gt 0) {        
        $endpoint = $response.CrmRecords[0]
    }

    return $endpoint
}

function Add-ServiceEndpoint
(
    [string] $SasKeyName,
    [string] $SasKey,
    [string] $Address,
    [string] $QueueName,
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient] $Connection
) {
    Write-Host "Checking for existing service endpoint for queue" $QueueName -ForegroundColor Green 

    $existing = Get-ServiceEndpoint -Connection $Connection -QueueName $QueueName

    $endpoint = @{ }
    $endpoint.Add("name", $QueueName)
    $endpoint.Add("namespaceaddress", $Address)   
    $endpoint.Add("saskeyname", $SasKeyName)
    $endpoint.Add("saskey", $Saskey)  
    $endpoint.Add("path", $QueueName)
    $endpoint.Add("authtype", (New-CrmOptionSetValue 2)) #sas key
    $endpoint.Add("contract", (New-CrmOptionSetValue 6)) #destination type = queue

    if ($existing) {
        Write-Host "Updating service endpoint for queue" $QueueName -ForegroundColor Green 
        Set-CrmRecord -conn $Connection -Fields $endpoint -Id $existing.serviceendpointid -EntityLogicalName "serviceendpoint"
    }
    else {
        Write-Host "Creating service endpoint for queue" $QueueName -ForegroundColor Green 
        $id = New-CrmRecord -conn $Connection -Fields $endpoint -EntityLogicalName "serviceendpoint"        
    }
}

function Update-ServiceEndpoint
(
    [Guid] $ServiceEndpointId,
    [string] $SasKey,
    [string] $Address,
    [string] $Path,
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient] $Conn
) {
    Write-Host "Updating service endpoint" $ServiceEndpointId

    $updateFields = @{ }
    $updateFields.Add("namespaceaddress", $Address)   
    $updateFields.Add("saskey", $Saskey)  
    $updateFields.Add("path", $Path)

    Set-CrmRecord -conn $Conn -Fields $updateFields -Id $ServiceEndpointId -EntityLogicalName "serviceendpoint"

    Write-Host "Service endpoint updated" $ServiceEndpointId
}