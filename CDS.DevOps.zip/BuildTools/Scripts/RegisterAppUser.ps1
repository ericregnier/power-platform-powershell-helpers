PARAM(
    [parameter(Mandatory=$true)][string]$ServerUrl,
    [parameter(Mandatory=$true)][string]$UserName,
    [parameter(Mandatory=$false)][string]$Password,
    [parameter(Mandatory=$true)][string]$ApplicationId,
    [parameter(Mandatory=$true)][string]$ApplicationUserUserName,
    [parameter(Mandatory=$true)][string]$FirstName,
    [parameter(Mandatory=$true)][string]$LastName,
    [parameter(Mandatory=$true)][string]$Email,
    [parameter(Mandatory=$true)][string]$RoleId
)    

function Add-ApplicationUser (
    [Guid] $ApplicationId,
    [string] $UserName,
    [Guid] $RoleId,
    [string] $Email,
    [string] $FirstName,
    [string] $LastName,
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient] $Connection
) {
    Write-Host "Creating app user" $ApplicationId -ForegroundColor Green 

    $fetchXml =
@"
<fetch>
    <entity name="systemuser"> 
        <attribute name="systemuserid" />
        <filter type="and">
            <condition attribute="applicationid" operator="eq" value="$ApplicationId" />
        </filter>
    </entity>
</fetch>
"@

    #Write-Host $fetchXml
    $response = Get-CrmRecordsByFetch -conn $Connection -Fetch $fetchXml

    if ($response.CrmRecords.Count -eq 0) {

        $fetchXml =
@"
<fetch>
    <entity name="businessunit"> 
        <attribute name="businessunitid" />
        <filter type="and">
        <condition attribute="parentbusinessunitid" operator="null" />
        </filter>
    </entity>
</fetch>
"@ 

        $response = Get-CrmRecordsByFetch -conn $Connection -Fetch $fetchXml
        if ($response.CrmRecords.Count -gt 0) {
            $user = @{ }
            $user.Add("applicationid", $ApplicationId)
            $user.Add("domainname", $UserName)
            $user.Add("internalemailaddress", $Email)       
            $user.Add("firstname", $FirstName)
            $user.Add("lastname", $LastName)

            $bu = new-object Microsoft.Xrm.Sdk.EntityReference
            $bu.LogicalName = "businessunit"
            $bu.Id = $response.CrmRecords[0].businessunitid

            $user.Add("businessunitid", $bu)

            $userId = New-CrmRecord -conn $Connection -EntityLogicalName systemuser -Fields $user
            Write-Host "App user" $ApplicationId "created" -ForegroundColor Green 

            if($null -ne $userId) {
                $relationship = new-object Microsoft.Xrm.Sdk.Relationship
                $relationship.SchemaName = "systemuserroles_association"

                $role = new-object Microsoft.Xrm.Sdk.EntityReference
                $role.LogicalName = "role"
                $role.Id = $RoleId
                
                $roles = new-object Microsoft.Xrm.Sdk.EntityReferenceCollection
                $roles.AddRange($role)

                Write-Host "Assigning role" $RoleId -ForegroundColor Green 
                $Connection.Associate("systemuser", $userId, $relationship, $roles);
                Write-Host "Role" $RoleId "assigned" -ForegroundColor Green 
            }
            else {
                Write-Host "Error occured creating user" -ForegroundColor Red 
            }
        }
        else {
            Write-Host "Business unit doesn't exist" -ForegroundColor Red 
        }
    }
    else {
        Write-Host "User" $ApplicationId "already exists" 
    }
}