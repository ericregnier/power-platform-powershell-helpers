﻿function Update-RootBU
(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient] $Conn,
    [string] $Name
) {
    Write-Host "Updating Root Business Unit Name to" $Name

    $fetchXml = 
    @"<fetch>
        <entity name="businessunit">
        <attribute name="name" />
        <attribute name="businessunitid" />
        <filter type="and">
            <condition attribute="parentbusinessunitid" operator="null" />
            <condition attribute="isdisabled" operator="eq" value="0" />
        </filter>
        </entity>
    </fetch>"@

    $results = Get-CrmRecordsByFetch -conn $Conn -Fetch $fetchXml 		
   
    if ($results.CrmRecords.Count -eq 1) {
        if ($results.CrmRecords[0].name -ne $Name) {
            $updateBusinessUnit = @{ }
            $updateBusinessUnit.Add("name", $Name)
         		
            Set-CrmRecord -conn $Conn -Fields $updateBusinessUnit -Id $businessunits.CrmRecords[0].businessunitid -EntityLogicalName "businessunit"
            Write-Host "Updated Root BU Name to" $Name
        }
    }
	Write-Host "Business Unit Name Update Done"
}
