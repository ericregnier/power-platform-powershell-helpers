﻿function Disable-DefaultProcesses
(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient] $Conn
) {   
    Write-Host "Disabling Default Processes"

    $fetchXml = 
    @"<fetch>
        <entity name="workflow" >
          <attribute name="workflowid" />
          <attribute name="name" />
          <filter type="and" >
            <condition attribute="statecode" operator="eq" value="1" />
            <filter type="or" >
                <condition attribute="workflowid" operator="eq" value="5DE74DCA-CCF3-4179-8C9D-BD7A1BF4C825" />
                <condition attribute="workflowid" operator="eq" value="6E9A821B-3CBC-4F04-9619-F2B723FE4880" />
                <condition attribute="workflowid" operator="eq" value="0FFBCDE4-61C1-4355-AA89-AA1D7B2B8792" />
                <condition attribute="workflowid" operator="eq" value="28920155-1862-4B42-8209-80BCE3694773" />
            </filter>
          </filter>
        </entity>
      </fetch>"@

    $processes = Get-CrmRecordsByFetch -conn $Conn -Fetch $fetchXml 		
 
    if ($processes.CrmRecords.Count -gt 0) {
        $processes.CrmRecords | ForEach-Object -Process {
            Write-Host "Disabling" $_.name       
            Set-CrmRecordState -conn $Conn -EntityLogicalName "workflow" -Id $_.workflowid -StateCode 0 -StatusCode 1
            Write-Host "Disabled" $_.name     
        }
    }
    Write-Host "Default Processes disabled"
}