﻿
#Spkl
* After updating the package from nuget, move CrmPluginRegistrationAttribute to Common shared project