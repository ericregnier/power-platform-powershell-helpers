declare namespace Rest {
  interface RestMapping<O, S, E, F, R> {
  }
  interface RestEntity {
  }
  interface dxc_devopsentityBase extends RestEntity {
  }
  interface dxc_devopsentityResult extends dxc_devopsentityBase {
  }
  interface dxc_devopsentity_Select {
  }
  interface dxc_devopsentity extends dxc_devopsentityBase {
  }
}
