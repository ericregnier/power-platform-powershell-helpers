type WebResourceImage = undefined
