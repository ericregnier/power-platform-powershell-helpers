declare const enum dxc_devopsentity_statecode {
  Active = 0,
  Inactive = 1,
}
