declare const enum dxc_devopsentity_statuscode {
  Active = 1,
  Inactive = 2,
}
