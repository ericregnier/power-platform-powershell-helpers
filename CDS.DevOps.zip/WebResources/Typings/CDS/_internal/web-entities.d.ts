interface WebMappingRetrieve<ISelect, IExpand, IFilter, IFixed, Result, FormattedResult> {
}
interface WebMappingCUDA<ICreate, IUpdate, ISelect> {
}
interface WebMappingRelated<ISingle, IMultiple> {
}
declare namespace Web {
  interface WebEntity {
  }
  interface WebEntity_Fixed {
    "@odata.etag": string;
  }
  interface dxc_devopsentity_Base extends WebEntity {
  }
  interface dxc_devopsentity_Fixed extends WebEntity_Fixed {
    dxc_devopsentityid: string;
  }
  interface dxc_devopsentity extends dxc_devopsentity_Base, dxc_devopsentity_Relationships {
  }
  interface dxc_devopsentity_Relationships {
  }
  interface dxc_devopsentity_Result extends dxc_devopsentity_Base, dxc_devopsentity_Relationships {
  }
  interface dxc_devopsentity_FormattedResult {
  }
  interface dxc_devopsentity_Select {
  }
  interface dxc_devopsentity_Expand {
  }
  interface dxc_devopsentity_Filter {
  }
  interface dxc_devopsentity_Create extends dxc_devopsentity {
  }
  interface dxc_devopsentity_Update extends dxc_devopsentity {
  }
}
