declare namespace Rest {
  interface dxc_devopsentityBase extends RestEntity {
    CreatedBy?: SDK.EntityReference | null;
    CreatedOn?: Date | null;
    CreatedOnBehalfBy?: SDK.EntityReference | null;
    ImportSequenceNumber?: number | null;
    ModifiedBy?: SDK.EntityReference | null;
    ModifiedOn?: Date | null;
    ModifiedOnBehalfBy?: SDK.EntityReference | null;
    OverriddenCreatedOn?: Date | null;
    OwnerId?: SDK.EntityReference | null;
    OwningBusinessUnit?: SDK.EntityReference | null;
    OwningTeam?: SDK.EntityReference | null;
    OwningUser?: SDK.EntityReference | null;
    TimeZoneRuleVersionNumber?: number | null;
    UTCConversionTimeZoneCode?: number | null;
    VersionNumber?: number | null;
    dxc_devopsentityId?: string | null;
    dxc_name?: string | null;
    statecode?: SDK.OptionSet<dxc_devopsentity_statecode> | null;
    statuscode?: SDK.OptionSet<dxc_devopsentity_statuscode> | null;
  }
  interface dxc_devopsentity extends dxc_devopsentityBase {
  }
  interface dxc_devopsentityResult extends dxc_devopsentityBase {
  }
  interface dxc_devopsentity_Select extends dxc_devopsentity_Expand {
    CreatedBy: RestAttribute<dxc_devopsentity_Select>;
    CreatedOn: RestAttribute<dxc_devopsentity_Select>;
    CreatedOnBehalfBy: RestAttribute<dxc_devopsentity_Select>;
    ImportSequenceNumber: RestAttribute<dxc_devopsentity_Select>;
    ModifiedBy: RestAttribute<dxc_devopsentity_Select>;
    ModifiedOn: RestAttribute<dxc_devopsentity_Select>;
    ModifiedOnBehalfBy: RestAttribute<dxc_devopsentity_Select>;
    OverriddenCreatedOn: RestAttribute<dxc_devopsentity_Select>;
    OwnerId: RestAttribute<dxc_devopsentity_Select>;
    OwningBusinessUnit: RestAttribute<dxc_devopsentity_Select>;
    OwningTeam: RestAttribute<dxc_devopsentity_Select>;
    OwningUser: RestAttribute<dxc_devopsentity_Select>;
    TimeZoneRuleVersionNumber: RestAttribute<dxc_devopsentity_Select>;
    UTCConversionTimeZoneCode: RestAttribute<dxc_devopsentity_Select>;
    VersionNumber: RestAttribute<dxc_devopsentity_Select>;
    dxc_devopsentityId: RestAttribute<dxc_devopsentity_Select>;
    dxc_name: RestAttribute<dxc_devopsentity_Select>;
    statecode: RestAttribute<dxc_devopsentity_Select>;
    statuscode: RestAttribute<dxc_devopsentity_Select>;
  }
  interface dxc_devopsentity_Filter {
    CreatedBy: XQR.EntityReferenceFilter;
    CreatedOn: Date;
    CreatedOnBehalfBy: XQR.EntityReferenceFilter;
    ImportSequenceNumber: number;
    ModifiedBy: XQR.EntityReferenceFilter;
    ModifiedOn: Date;
    ModifiedOnBehalfBy: XQR.EntityReferenceFilter;
    OverriddenCreatedOn: Date;
    OwnerId: XQR.EntityReferenceFilter;
    OwningBusinessUnit: XQR.EntityReferenceFilter;
    OwningTeam: XQR.EntityReferenceFilter;
    OwningUser: XQR.EntityReferenceFilter;
    TimeZoneRuleVersionNumber: number;
    UTCConversionTimeZoneCode: number;
    VersionNumber: number;
    dxc_devopsentityId: XQR.Guid;
    dxc_name: string;
    statecode: XQR.ValueContainerFilter<dxc_devopsentity_statecode>;
    statuscode: XQR.ValueContainerFilter<dxc_devopsentity_statuscode>;
  }
  interface dxc_devopsentity_Expand {
  }
}
interface RestEntities {
  dxc_devopsentity: RestMapping<Rest.dxc_devopsentity,Rest.dxc_devopsentity_Select,Rest.dxc_devopsentity_Expand,Rest.dxc_devopsentity_Filter,Rest.dxc_devopsentityResult>;
}
