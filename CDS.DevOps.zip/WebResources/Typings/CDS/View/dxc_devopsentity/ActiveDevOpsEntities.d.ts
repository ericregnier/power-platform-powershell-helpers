declare namespace Views.dxc_devopsentity {
  interface ActiveDevOpsEntities {
    dxc_name: string;
    dxc_name_Value: string;
    dxc_devopsentityid: string;
    dxc_devopsentityid_Value: string;
    createdon: string;
    createdon_Value: Date;
  }
}
