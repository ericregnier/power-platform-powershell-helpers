declare namespace SDK {
  namespace REST {
    function createRecord(object: Rest.dxc_devopsentity, type: "dxc_devopsentity", successCallback: (result: Rest.dxc_devopsentityResult) => any, errorCallback: (err: Error) => any): void;
    function deleteRecord(id: string, type: "dxc_devopsentity", successCallBack: () => any, errorCallback: (err: Error) => any): void;
    function retrieveRecord(id: string, type: "dxc_devopsentity", select: string | null, expand: string | null, successCallback: (result: Rest.dxc_devopsentityResult) => any, errorCallback: (err: Error) => any): void;
    function updateRecord(id: string, object: Rest.dxc_devopsentity, type: "dxc_devopsentity", successCallBack: () => any, errorCallback: (err: Error) => any): void;
    function retrieveMultipleRecords(type: "dxc_devopsentity", options: string, successCallback: (result: Rest.dxc_devopsentityResult[]) => any, errorCallback: (err: Error) => any, onComplete: any): void;
    function createRecord(object: Rest.RestEntity, type: string, successCallback: (result: Rest.RestEntity) => any, errorCallback: (err: Error) => any): void;
    function deleteRecord(id: string, type: string, successCallBack: () => any, errorCallback: (err: Error) => any): void;
    function retrieveRecord(id: string, type: string, select: string | null, expand: string | null, successCallback: (result: Rest.RestEntity) => any, errorCallback: (err: Error) => any): void;
    function updateRecord(id: string, object: Rest.RestEntity, type: string, successCallBack: () => any, errorCallback: (err: Error) => any): void;
    function retrieveMultipleRecords(type: string, options: string, successCallback: (result: Rest.RestEntity[]) => any, errorCallback: (err: Error) => any, onComplete: any): void;
    function associateRecords(parentId: string, parentType: string, relationshipName: string, childId: string, childType: string, successCallBack: () => any, errorCallback: (err: Error) => any): void;
    function disassociateRecords(parentId: string, parentType: string, relationshipName: string, childId: string, childType: string, successCallBack: () => any, errorCallback: (err: Error) => any): void;
  }
}
