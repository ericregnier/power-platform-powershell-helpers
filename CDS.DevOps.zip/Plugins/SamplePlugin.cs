﻿using D365.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D365.Template.Plugins
{
    [CrmPluginRegistration(MessageNameEnum.Update
        , "dxc_devopsentity"
        , StageEnum.PreOperation
        , ExecutionModeEnum.Synchronous
        , "name"
        , "Update of DevOps Entity"
        , 1
        , IsolationModeEnum.Sandbox
        , Description = "Description")]
    public class SamplePlugin : BasePlugin
    {
        protected override void Execute(LocalPluginContext localcontext)
        {
            throw new NotImplementedException();
        }
    }
}
