﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Plugins.Tests
{
    [TestClass]
    public class SampleUnitTest
    {
        [TestMethod]
        public void SampleMethod()
        {
            Assert.IsTrue(true);
        }
    }
}
